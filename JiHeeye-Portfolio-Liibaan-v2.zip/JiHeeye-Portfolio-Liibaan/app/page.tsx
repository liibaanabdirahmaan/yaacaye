'use client';

import Image from "next/image";
import { useState } from "react";
import { ArrowUpRight, Github, Linkedin, Mail, Menu, X, Code2, Database, Globe, Smartphone } from "lucide-react";

const projects = [
  {title:"Dharag Restaurant", tag:"E-commerce", text:"Restaurant e-commerce with menu browsing, cart, customer ordering and delivery flow.", tech:"Next.js • TypeScript • CSS", image:"/projects/dharag-restaurant.png", href:"#contact"},
  {title:"JiHeeye Portfolio", tag:"Personal Brand", text:"A responsive developer portfolio for skills, selected work and professional contact details.", tech:"Next.js • React • TypeScript", image:"/projects/portfolio-preview.png", href:"#home"},
  {title:"Restaurant Admin", tag:"Dashboard", text:"Admin experience for managing orders, customers, menu items and business activity.", tech:"React • TypeScript • UI", image:"/projects/restaurant-admin.svg", href:"#contact"},
  {title:"Online Store", tag:"E-commerce", text:"Shopping experience with product cards, search, categories, cart and checkout concepts.", tech:"Next.js • React • Responsive UI", image:"/projects/online-store.svg", href:"#contact"},
];

export default function Home() {
  const [open,setOpen] = useState(false);
  return (
    <main>
      <nav className="nav">
        <a className="brand" href="#home">Ji<span>Heeye</span>.</a>
        <div className={open ? "links open":"links"}>
          <a href="#home" onClick={()=>setOpen(false)}>Home</a>
          <a href="#about" onClick={()=>setOpen(false)}>About</a>
          <a href="#skills" onClick={()=>setOpen(false)}>Skills</a>
          <a href="#projects" onClick={()=>setOpen(false)}>Projects</a>
          <a href="#contact" onClick={()=>setOpen(false)}>Contact</a>
        </div>
        <a className="navBtn" href="#contact">Let's talk <ArrowUpRight size={17}/></a>
        <button className="menu" onClick={()=>setOpen(!open)} aria-label="menu">{open?<X/>:<Menu/>}</button>
      </nav>

      <section id="home" className="hero">
        <div className="glow"/>
        <div className="heroText">
          <p className="eyebrow">FULL STACK DEVELOPER</p>
          <h1>Building digital<br/><span>experiences</span> that matter.</h1>
          <p className="lead">I'm <b>Liibaan Abdirahmaan Yuusuf</b>, a developer focused on modern web applications, elegant interfaces and practical digital products.</p>
          <div className="actions">
            <a className="primary" href="#projects">View my work <ArrowUpRight size={18}/></a>
            <a className="secondary" href="#contact">Contact me</a>
          </div>
          <div className="stats"><div><b>3+</b><span>Years learning</span></div><div><b>10+</b><span>Projects</span></div><div><b>24/7</b><span>Curiosity</span></div></div>
        </div>
        <div className="heroCard">
          <div className="profileFrame"><Image className="profilePhoto" src="/profile.jpeg" alt="Liibaan Abdirahmaan Yuusuf" width={862} height={1080} priority /></div>
          <div className="cardLine"/>
          <p>Liibaan Abdirahmaan Yuusuf</p>
          <small>Full Stack Developer • Code. Design. Build.</small>
        </div>
      </section>

      <section id="about" className="section about">
        <div><p className="eyebrow">ABOUT ME</p><h2>Developer with a<br/><span>product mindset.</span></h2></div>
        <div><p>I enjoy taking an idea from a rough concept to a polished, responsive web experience. My focus is on clean code, thoughtful UX and interfaces that feel simple to use.</p><p>I work across frontend and backend technologies and I'm always learning better ways to build.</p></div>
      </section>

      <section id="skills" className="section">
        <p className="eyebrow">WHAT I DO</p><h2>Skills & <span>tools.</span></h2>
        <div className="skillGrid">
          <article><Code2/><h3>Frontend</h3><p>React, Next.js, TypeScript, HTML, CSS and responsive UI.</p></article>
          <article><Database/><h3>Backend</h3><p>APIs, databases, authentication and application logic.</p></article>
          <article><Globe/><h3>Web</h3><p>Modern websites optimized for usability, speed and mobile.</p></article>
          <article><Smartphone/><h3>Product UI</h3><p>Dashboards, ordering flows, forms and customer experiences.</p></article>
        </div>
      </section>

      <section id="projects" className="section projects">
        <div className="sectionTop"><div><p className="eyebrow">SELECTED WORK</p><h2>Projects I’ve <span>built.</span></h2></div></div>
        <div className="projectGrid">{projects.map((p,i)=><a className="project" key={p.title} href={p.href}><div className="projectVisual"><Image src={p.image} alt={p.title} fill sizes="(max-width: 850px) 100vw, 33vw"/><div className="projectOverlay"><span>0{i+1}</span><ArrowUpRight/></div></div><div className="tag">{p.tag}</div><h3>{p.title}</h3><p>{p.text}</p><small>{p.tech}</small><div className="projectLink">View project <ArrowUpRight size={15}/></div></a>)}</div>
      </section>

      <section id="contact" className="contact">
        <p className="eyebrow">LET'S CONNECT</p><h2>Have an idea?<br/><span>Let’s build it.</span></h2>
        <p>I'm open to freelance work, collaborations and interesting projects.</p>
        <div className="contactActions"><a className="primary" href="mailto:liibaanupdy3@icloud.com">Send me an email <Mail size={18}/></a><a className="secondary" href="tel:+252616425589">Call +252 61 642 5589</a></div>
        <div className="socials"><a href="https://github.com/" target="_blank" rel="noreferrer" aria-label="GitHub"><Github/></a><a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn"><Linkedin/></a><a href="mailto:liibaanupdy3@icloud.com" aria-label="Email"><Mail/></a></div>
      </section>

      <footer><b>JiHeeye.</b><span>© 2026 Liibaan Abdirahmaan Yuusuf. Built with Next.js.</span></footer>
    </main>
  );
}
