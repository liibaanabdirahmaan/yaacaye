import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "JiHeeye — Full Stack Developer",
  description: "Portfolio of Liibaan Updyrahmaan Yuusuf",
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
